import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ChurchIcon as Temple } from "lucide-react"

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-green-50 to-blue-50 dark:from-green-950 dark:to-blue-950">
      <div className="container mx-auto flex flex-1 flex-col items-center justify-center px-4 py-16 text-center">
        <div className="animate-fade-in-up">
          <div className="mb-6 flex items-center justify-center">
            <Temple className="h-16 w-16 text-green-600 dark:text-green-400" />
          </div>
          <h1 className="mb-4 text-4xl font-extrabold tracking-tight text-green-800 dark:text-green-300 sm:text-5xl md:text-6xl">
            Kainchi Dham
          </h1>
          <p className="mb-8 max-w-2xl text-xl text-green-700 dark:text-green-400">
            Real-time traffic management and visitor information system
          </p>
          <div className="flex flex-col space-y-4 sm:flex-row sm:space-x-4 sm:space-y-0">
            <Link href="/auth">
              <Button className="bg-green-600 hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-600">
                Admin Login
              </Button>
            </Link>
            <Link href="/public-info">
              <Button
                variant="outline"
                className="border-green-600 text-green-600 hover:bg-green-50 dark:border-green-500 dark:text-green-400 dark:hover:bg-green-950"
              >
                Visitor Information
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
