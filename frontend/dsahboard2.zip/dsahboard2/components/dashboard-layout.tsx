"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  BarChart3,
  Bell,
  Calendar,
  Clock,
  Home,
  Layers,
  LogOut,
  Map,
  Menu,
  Moon,
  Sun,
  ChurchIcon as Temple,
  Users,
  X,
  Info,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { useTheme } from "next-themes"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface NavItem {
  title: string
  href: string
  icon: React.ReactNode
  badge?: number
}

const navItems: NavItem[] = [
  {
    title: "Dashboard",
    href: "/dashboard",
    icon: <Home className="h-5 w-5" />,
  },
  {
    title: "Map & Simulation",
    href: "/dashboard/map",
    icon: <Map className="h-5 w-5" />,
  },
  {
    title: "Scenario Simulator",
    href: "/dashboard/simulator",
    icon: <Layers className="h-5 w-5" />,
    badge: 2,
  },
  {
    title: "Queue Manager",
    href: "/dashboard/queue",
    icon: <Clock className="h-5 w-5" />,
  },
  {
    title: "Public Info",
    href: "/dashboard/public-info",
    icon: <Users className="h-5 w-5" />,
  },
  {
    title: "Analytics",
    href: "/dashboard/analytics",
    icon: <BarChart3 className="h-5 w-5" />,
  },
  {
    title: "Events Calendar",
    href: "/dashboard/events",
    icon: <Calendar className="h-5 w-5" />,
    badge: 1,
  },
  {
    title: "About Us",
    href: "/dashboard/about",
    icon: <Info className="h-5 w-5" />,
  },
]

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const pathname = usePathname()
  const { theme, setTheme } = useTheme()
  const [isMounted, setIsMounted] = useState(false)
  const [isMobile, setIsMobile] = useState(false)
  const [isOpen, setIsOpen] = useState(false)

  useEffect(() => {
    setIsMounted(true)
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }
    checkMobile()
    window.addEventListener("resize", checkMobile)
    return () => window.removeEventListener("resize", checkMobile)
  }, [])

  if (!isMounted) {
    return null
  }

  return (
    <div className="flex min-h-screen flex-col bg-background transition-colors duration-300">
      {/* Top Navigation */}
      <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b bg-background px-4 shadow-sm transition-all duration-300 md:px-6">
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="md:hidden">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle Menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-64 p-0 sm:max-w-xs">
            <div className="flex h-full flex-col">
              <div className="flex items-center border-b p-4">
                <Temple className="mr-2 h-6 w-6 text-green-600 dark:text-green-400" />
                <h2 className="text-lg font-semibold">Kainchi Dham</h2>
                <Button variant="ghost" size="icon" className="ml-auto" onClick={() => setIsOpen(false)}>
                  <X className="h-5 w-5" />
                </Button>
              </div>
              <nav className="flex-1 overflow-auto py-4">
                <div className="grid gap-1 px-2">
                  {navItems.map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      onClick={() => setIsOpen(false)}
                      className={`group flex items-center justify-between rounded-lg px-3 py-2 text-sm transition-all duration-200 ${
                        pathname === item.href
                          ? "bg-green-100 text-green-900 dark:bg-green-900 dark:text-green-50"
                          : "text-muted-foreground hover:bg-green-50 hover:text-green-900 dark:hover:bg-green-900/30 dark:hover:text-green-50"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`${pathname === item.href ? "text-green-600 dark:text-green-400" : ""}`}>
                          {item.icon}
                        </div>
                        {item.title}
                      </div>
                      {item.badge && <Badge className="bg-green-600 dark:bg-green-500">{item.badge}</Badge>}
                    </Link>
                  ))}
                </div>
              </nav>
              <div className="border-t p-4">
                <Link href="/">
                  <Button variant="outline" className="w-full justify-start gap-2">
                    <LogOut className="h-4 w-4" />
                    Logout
                  </Button>
                </Link>
              </div>
            </div>
          </SheetContent>
        </Sheet>
        <div className="flex items-center gap-2">
          <Temple className="h-6 w-6 text-green-600 dark:text-green-400" />
          <span className="text-lg font-semibold tracking-tight">Kainchi Dham Traffic Control</span>
        </div>
        <div className="ml-auto flex items-center gap-4">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                  className="animate-fade-in transition-all duration-300 hover:text-green-600 dark:hover:text-green-400"
                >
                  {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
                  <span className="sr-only">Toggle theme</span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>{theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  size="icon"
                  className="relative animate-fade-in transition-all duration-300 hover:text-green-600 dark:hover:text-green-400"
                >
                  <Bell className="h-5 w-5" />
                  <Badge className="absolute -right-1 -top-1 h-5 w-5 animate-pulse rounded-full bg-red-500 p-0 text-xs text-white">
                    3
                  </Badge>
                  <span className="sr-only">Notifications</span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>You have 3 unread notifications</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <Avatar className="transition-transform duration-300 hover:scale-110">
            <AvatarFallback className="bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100">
              AD
            </AvatarFallback>
          </Avatar>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex flex-1">
        {/* Sidebar (desktop only) */}
        <aside className="hidden w-64 border-r bg-background transition-all duration-300 md:block">
          <nav className="grid gap-1 p-4">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`group flex items-center justify-between rounded-lg px-3 py-2 text-sm transition-all duration-200 ${
                  pathname === item.href
                    ? "bg-green-100 text-green-900 dark:bg-green-900 dark:text-green-50"
                    : "text-muted-foreground hover:bg-green-50 hover:text-green-900 dark:hover:bg-green-900/30 dark:hover:text-green-50"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`transition-colors duration-200 ${pathname === item.href ? "text-green-600 dark:text-green-400" : "group-hover:text-green-600 dark:group-hover:text-green-400"}`}
                  >
                    {item.icon}
                  </div>
                  {item.title}
                </div>
                {item.badge && <Badge className="bg-green-600 dark:bg-green-500">{item.badge}</Badge>}
              </Link>
            ))}
          </nav>
        </aside>

        {/* Page Content */}
        <main className="flex-1 overflow-auto transition-all duration-300">{children}</main>
      </div>
    </div>
  )
}
